 <!-- MENU SIDEBAR-->
 <aside class="menu-sidebar d-none d-lg-block">
            <div class="logo">
                <a href="#">
                    <img src="images/icon/logo.png" alt="Cool Admin" />
                </a>
            </div>
            <div class="menu-sidebar__content js-scrollbar1">
                <nav class="navbar-sidebar">
                    <ul class="list-unstyled navbar__list">
                        <li class="active has-sub">
                            <a class="js-arrow" href="index.php">
                                <i class="fas fa-tachometer-alt"></i>Dashboard</a>
                            <ul class="list-unstyled navbar__sub-list js-sub-list">
                               <!-- <li>
                                    <a href="index.php">Dashboard 1</a>
                                </li>
                                <li>
                                    <a href="index.php">Dashboard 2</a>
                                </li>
                                <li>
                                    <a href="index.php">Dashboard 3</a>
                                </li>
                                <li>
                                    <a href="index.php">Dashboard 4</a>
                                </li>-->
                            </ul>
                        </li>

                        <li>
                            
                                <a class="js-arrow" href="#">
                                <i class="fas fa-table"></i>Tables</a>
                            <ul class="list-unstyled navbar__sub-list js-sub-list">
                                    <li><a href="admin_table.php">1. Admin</a> </li>
                                    <li><a href="package_table.php">2. Package</a> </li>
			                        <li><a href="users_table.php">3. Users</a> </li>
                                    <li><a href="feedback_table.php">4. Feedback</a> </li>						
                                    <li><a href="category_table.php">5. Category</a> </li>
			                        <li><a href="pgmaster_table.php">6. PG Master</a> </li>
			                        <li><a href="pgphotos_table.php">7. PG photos</a> </li>
			                        <li><a href="owner_table.php">8. Owner</a> </li>
			                        <li><a href="payment_table.php">9. Payment</a> </li>
                                    <li><a href="booking_table.php">10. Booking</a> </li>
                            </ul>   
                        </li>

                        <li>
                            <a class="js-arrow" href="#">
                                <i class="far fa-check-square"></i>Forms</a>
                            <ul class="list-unstyled navbar__sub-list js-sub-list">
                            <li><a href="admin_form.php">1. Admin</a> </li>
                            <li><a href="package_form.php">2. Package</a> </li>
			                <li><a href="users_form.php">3. Users</a> </li>
                            <li><a href="feedback_form.php">4. Feedback</a> </li>		
                            <li><a href="category_form.php">5. Category</a> </li>				
                            <li><a href="pgmaster_form.php">6. PG Master</a> </li>
                            <li><a href="pgphotos_form.php">7. PG Photos</a> </li>
                            <li><a href="owner_form.php">8. Owner</a> </li>
                            <li><a href="payment_form.php">9. Payment</a> </li>
                            <li><a href="booking_form.php">10. Booking</a> </li>
                            </ul>
                        </li>
                        <li class="has-sub">
                            <a class="js-arrow" href="#">
                                <i class="fas fa-copy"></i>Pages</a>
                            <ul class="navbar-mobile-sub__list list-unstyled js-sub-list">
                                <li>
                                    <a href="login.php">Login</a>
                                </li>
                                <li>
                                    <a href="register.php">Register</a>
                                </li>
                                <li>
                                    <a href="forget-pass.php">Forget Password</a>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </nav>
            </div>
        </aside>
        <!-- END MENU SIDEBAR-->