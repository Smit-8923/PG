<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from ary-themes.com/html/noor_tech/dream-property/booking.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 04 Mar 2021 11:00:06 GMT -->
<head>
<meta charset="utf-8">
<title>BOOK MY PG | Booking</title>
<!-- Stylesheets -->
<link href="css/bootstrap.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">
<link href="css/responsive.css" rel="stylesheet">

<!--Color Switcher Mockup-->
<link href="css/color-switcher-design.css" rel="stylesheet">
<!--Color Themes-->
<link id="theme-color-file" href="css/color-themes/default-theme.css" rel="stylesheet">

<link rel="shortcut icon" href="images/favicon.png" type="image/x-icon">
<link rel="icon" href="images/favicon.png" type="image/x-icon">

<!-- Responsive -->
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
<!--[if lt IE 9]><script src="https://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.3/html5shiv.js"></script><![endif]-->
<!--[if lt IE 9]><script src="js/respond.js"></script><![endif]-->
</head>

<body>

<div class="page-wrapper">
    <!-- Preloader -->
    <div class="preloader"></div>

   <?php
			include './themepart/header.php';
   ?>
    <!-- End Main Header -->
	
	<!-- Page Title -->
    <section class="page-title" style="background-image:url(images/background/2.jpg);">
    	<div class="auto-container">
        	<div class="inner-box">
                <h1>Booking</h1>
                <div class="bread-crumb"><a href="index.html">Home &nbsp; /</a> <i class="current">Booking</i></div>
            </div>
        </div>
    </section>
	<!-- End Page Title -->
	
	<!-- Booking Section -->
	<section class="booking-section">
		<div class="auto-container">
			<!-- Booking Header -->
			<div class="booking-dashboard-header">
				<div class="row clearfix">
					<!-- Column -->
					<div class="column col-lg-6 col-md-12 col-sm-12">
						<h1>Booking.</h1>
					</div>
					<!-- Column -->
					<div class="column col-lg-6 col-md-12 col-sm-12">
						<ul class="dashboard-nav">
							<li><a href="index.html">Index</a></li>
							<li><a href="messages.html">Messages</a></li>
							<li class="active"><a href="booking.html">Booking</a></li>
							<li><a href="dashboard.html">Dashboard</a></li>
							<li><a href="submit-property.html">Submit Property</a></li>
						</ul>
					</div>
				</div>
			</div>
			
			<div class="section-inner">
				<h3>Booking List</h3>
				
				<!--comment-->
				<article class="message-box">
					<div class="thumb-box">
						<figure class="thumb"><img src="images/resource/author-1.jpg" alt=""></figure>
						<a href="#" class="reply-btn">Reply Now</a>
					</div>
					<div class="content-box">
						<div class="name">Monija Moro</div>
						<span class="date"><i class="la la-calendar"></i> 8:42 PM 1/28/2019</span>
						<ul class="booking-info">
							<li><strong>Item </strong> Real Luxury Apartment</li>
							<li><strong>Start date </strong> 18 November 2019</li>
							<li><strong>End date </strong> 18 November 2019</li>
							<li><strong>Booking details </strong> 5 Peoples</li>
							<li><strong>Mail </strong><a href="mailto:info@Dream Property.com">info@Dream Property.com</a></li>
							<li><strong>Phone </strong><a href="tel:+000-000-000">+000-000-000</a></li>
						</ul>
						<div class="btn-box">
							<a href="#">Approve <i class="pe-7s-check"></i></a>
							<a href="#">Reject <i class="pe-7s-close-circle"></i></a>
						</div>
					</div>
				</article>
				
				<!--comment-->
				<article class="message-box">
					<div class="thumb-box">
						<figure class="thumb"><img src="images/resource/author-2.jpg" alt=""></figure>
						<a href="#" class="reply-btn">Reply Now</a>
					</div>
					<div class="content-box">
						<div class="name">Micheal Clark</div>
						<span class="date"><i class="la la-calendar"></i> 8:42 PM 1/28/2019</span>
						<ul class="booking-info">
							<li><strong>Item </strong> Real Luxury Apartment</li>
							<li><strong>Start date </strong> 18 November 2019</li>
							<li><strong>End date </strong> 18 November 2019</li>
							<li><strong>Booking details </strong> 5 Peoples</li>
							<li><strong>Mail </strong><a href="mailto:info@Dream Property.com">info@Dream Property.com</a></li>
							<li><strong>Phone </strong><a href="tel:+000-000-000">+000-000-000</a></li>
						</ul>
						<div class="btn-box">
							<a href="#">Approve <i class="pe-7s-check"></i></a>
							<a href="#">Reject <i class="pe-7s-close-circle"></i></a>
						</div>
					</div>
				</article>
				
				<!--comment-->
				<article class="message-box">
					<div class="thumb-box">
						<figure class="thumb"><img src="images/resource/author-3.jpg" alt=""></figure>
						<a href="#" class="reply-btn">Reply Now</a>
					</div>
					<div class="content-box">
						<div class="name">Rickey Ponting</div>
						<span class="date"><i class="la la-calendar"></i> 8:42 PM 1/28/2019</span>
						<ul class="booking-info">
							<li><strong>Item </strong> Real Luxury Apartment</li>
							<li><strong>Start date </strong> 18 November 2019</li>
							<li><strong>End date </strong> 18 November 2019</li>
							<li><strong>Booking details </strong> 5 Peoples</li>
							<li><strong>Mail </strong><a href="mailto:info@Dream Property.com">info@Dream Property.com</a></li>
							<li><strong>Phone </strong><a href="tel:+000-000-000">+000-000-000</a></li>
						</ul>
						<div class="btn-box">
							<a href="#">Approve <i class="pe-7s-check"></i></a>
							<a href="#">Reject <i class="pe-7s-close-circle"></i></a>
						</div>
					</div>
				</article>
				
			</div>
			
		</div>
	</section>
	<!-- End Submit Property Section -->
	
	<!--Newsleter Section-->
    <section class="newsletter-section" style="background-image:url(images/background/1.jpg)">
    	<div class="auto-container">
        	<div class="inner-container">
            	<div class="row clearfix">
                	
                    <!--Title Column-->
                    <div class="title-column col-lg-5 col-md-12 col-sm-12">
                    	<div class="inner-column">
                        	<div class="icon-box">
                            	<span class="icon flaticon-door-knob"></span>
                            </div>
                            <h4>Newsletter Subscription</h4>
                            <div class="title">Get latest news & updates</div>
                        </div>
                    </div>
                    
                    <!--Form Column-->
                    <div class="form-column col-lg-7 col-md-12 col-sm-12">
                    	<div class="inner-column">
                        	
                            <!--Subscribe Form-->
                            <div class="subscribe-form">
                                <form method="post" action="http://ary-themes.com/html/noor_tech/dream-property/contact.html">
                                    <div class="form-group">
                                        <input type="email" name="email" value="" placeholder="Email Address" required>
                                        <button type="submit" class="submit-btn">Submit Now</button>
                                    </div>
                                </form>
                            </div>
                            
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
    </section>
    <!--End Newsleter Section-->
	
	<!--Main Footer-->
    <?php 
			include './themepart/footer.php';
	?>
	
</div>
<!--End pagewrapper-->

<!--Scroll to top-->
<div class="scroll-to-top scroll-to-target" data-target="html"><span class="fa fa-angle-up"></span></div>

<!--Search Popup-->
<div id="search-popup" class="search-popup">
	<div class="close-search theme-btn"><span class="fas fa-window-close"></span></div>
	<div class="popup-inner">
		<div class="overlay-layer"></div>
    	<div class="search-form">
        	<form method="post" action="http://ary-themes.com/html/noor_tech/dream-property/index.html">
            	<div class="form-group">
                	<fieldset>
                        <input type="search" class="form-control" name="search-input" value="" placeholder="Search Here" required >
                        <input type="submit" value="Search Now!" class="theme-btn">
                    </fieldset>
                </div>
            </form>
            
            <br>
            <h3>Recent Search Keywords</h3>
            <ul class="recent-searches">
                <li><a href="#">Business</a></li>
                <li><a href="#">Appartment</a></li>
                <li><a href="#">Flat</a></li>
                <li><a href="#">Commercial</a></li>
                <li><a href="#">Villa</a></li>
            </ul>
        
        </div>
        
    </div>
</div>

<!-- Color Palate / Color Switcher -->
<div class="color-palate">
    <div class="color-trigger">
        <i class="fas fa-cog"></i>
    </div>
    <div class="color-palate-head">
        <h6>Choose Your Color</h6>
    </div>
    <div class="various-color clearfix">
        <div class="colors-list">
            <span class="palate default-color active" data-theme-file="css/color-themes/default-theme.css"></span>
            <span class="palate yellow-color" data-theme-file="css/color-themes/yellow-theme.css"></span>
            <span class="palate olive-color" data-theme-file="css/color-themes/olive-theme.css"></span>
            <span class="palate orange-color" data-theme-file="css/color-themes/orange-theme.css"></span>
            <span class="palate purple-color" data-theme-file="css/color-themes/purple-theme.css"></span>
            <span class="palate teal-color" data-theme-file="css/color-themes/teal-theme.css"></span>
            <span class="palate brown-color" data-theme-file="css/color-themes/brown-theme.css"></span>
            <span class="palate redd-color" data-theme-file="css/color-themes/redd-color.css"></span>
        </div>
    </div>
	
	<ul class="rtl-version option-box"> <li class="rtl">RTL Version</li> <li>LTR Version</li> </ul>

    <a href="#" class="purchase-btn">Purchase now $17</a>
    
    <div class="palate-foo">
        <span>You will find much more options for colors and styling in admin panel. This color picker is used only for demonstation purposes.</span>
    </div>

</div>

<!--Scroll to top-->
<script src="js/jquery.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/jquery-ui.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.fancybox.js"></script>
<script src="js/jquery.countdown.js"></script>
<script src="js/dropzone.js"></script>
<script src="js/owl.js"></script>
<script src="js/wow.js"></script>
<script src="js/dropzone.js"></script>
<script src="js/appear.js"></script>
<script src="js/script.js"></script>
<script src="js/color-settings.js"></script>

</body>

<!-- Mirrored from ary-themes.com/html/noor_tech/dream-property/booking.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 04 Mar 2021 11:00:06 GMT -->
</html>