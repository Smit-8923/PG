<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from ary-themes.com/html/noor_tech/dream-property/checkout.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 04 Mar 2021 10:57:05 GMT -->
<head>
<meta charset="utf-8">
<title>BOOK MY PG | Checkout</title>
<!-- Stylesheets -->
<link href="css/bootstrap.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">
<link href="css/responsive.css" rel="stylesheet">

<!--Color Switcher Mockup-->
<link href="css/color-switcher-design.css" rel="stylesheet">
<!--Color Themes-->
<link id="theme-color-file" href="css/color-themes/default-theme.css" rel="stylesheet">

<link rel="shortcut icon" href="images/favicon.png" type="image/x-icon">
<link rel="icon" href="images/favicon.png" type="image/x-icon">

<!-- Responsive -->
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
<!--[if lt IE 9]><script src="https://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.3/html5shiv.js"></script><![endif]-->
<!--[if lt IE 9]><script src="js/respond.js"></script><![endif]-->
</head>

<body>

<div class="page-wrapper">
    <!-- Preloader -->
    <div class="preloader"></div>

   <?php   
            include './themepart/header.php';
   ?>
    <!-- End Main Header -->
	
	<!-- Page Title -->
    <section class="page-title" style="background-image:url(images/background/2.jpg);">
    	<div class="auto-container">
        	<div class="inner-box">
                <h1>Checkout</h1>
                <div class="bread-crumb"><a href="index.html">Home &nbsp; /</a> <i class="current">Checkout</i></div>
            </div>
        </div>
    </section>
	<!-- End Page Title -->
	
	<!--Checkout Page-->
    <div class="checkout-page">
        <div class="auto-container">
            	
            <!--Default Links-->
            <ul class="default-links">
                <li>Returning customer? <a href="login.php">Click here to login</a></li>
            </ul>
                
            <!--Billing Details-->
            <div class="billing-details">
                <div class="shop-form">
                    <form method="post" action="http://ary-themes.com/html/noor_tech/dream-property/checkout.html">
                        <div class="row clearfix">
                            <div class="col-lg-7 col-md-12 col-sm-12">
                				<div class="sec-title">
									<h1>Billing Details.</h1>
									<div class="separator"></div>
								</div>
                        		<div class="billing-inner">
                                    <div class="row clearfix">
                                        
                                        <!--Form Group-->
                                        <div class="form-group col-md-6 col-sm-6 col-xs-12">
                                            <div class="field-label">First name <sup>*</sup></div>
                                            <input type="text" name="field-name" value="" placeholder="First Name">
                                        </div>
                                        
                                        <!--Form Group-->
                                        <div class="form-group col-md-6 col-sm-6 col-xs-12">
                                            <div class="field-label">Last name <sup>*</sup></div>
                                            <input type="text" name="field-name" value="" placeholder="Last Name">
                                        </div>
                                        
                                        <!--Form Group-->
                                        <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                            <div class="field-label">Company name </div>
                                            <input type="text" name="field-name" value="" placeholder="Company name">
                                        </div>
                                        
                                        <!--Form Group-->
                                        <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                            <div class="field-label">Email Address <sup>*</sup></div>
                                            <input type="email" name="field-name" value="" placeholder="Street Address">
                                            <input class="address-two" type="email" name="field-name" value="" placeholder="Apartment, Suit unit etc (optional)">
                                        </div>
                                        
                                        <!--Form Group-->
                                        <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                            <div class="field-label">Town / City <sup>*</sup></div>
                                            <input type="text" name="field-name" value="" placeholder="Town /City">
                                        </div>
                                        
                                        <!--Form Group-->
                                        <div class="form-group col-md-6 col-sm-6 col-xs-12">
                                            <div class="field-label">State / Country <sup>*</sup> </div>
                                            <select name="country">
                                                <option>Select an option</option>
                                                <option>Pakistan</option>
                                                <option>USA</option>
                                                <option>CANADA</option>
                                                <option>INDIA</option>
                                            </select>
                                        </div>
                                        
                                        <!--Form Group-->
                                        <div class="form-group col-md-6 col-sm-6 col-xs-12">
                                            <div class="field-label">Postcode / Zip <sup>*</sup></div>
                                            <input type="text" name="code" value="" placeholder="Postcode / Zip">
                                        </div>
                                        
                                        <!--Form Group-->
                                        <div class="form-group col-md-6 col-sm-6 col-xs-12">
                                            <div class="field-label">Email Address <sup>*</sup></div>
                                            <input type="text" name="field-name" value="" placeholder="Email Address">
                                        </div>
                                        
                                        <!--Form Group-->
                                        <div class="form-group col-md-6 col-sm-6 col-xs-12">
                                            <div class="field-label">Phone <sup>*</sup></div>
                                            <input type="text" name="field-name" value="" placeholder="Select an option">
                                        </div>
                                        
                                        <div class="form-group col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                            <div class="check-box"><input type="checkbox" name="shipping-option" id="account-option"> &ensp; <label for="account-option">Creat an account?</label></div>
                                        </div>
                                        
                                        <div class="form-group col-lg-12 col-md-12 col-xs-12">
                                        	<div class="sec-title">
                                        		<h1>Ship to Different Address</h1>
												<div class="separator"></div>
                                        	</div>
                                        
                                            <div class="field-label">Order Notes</div>
                                            <textarea placeholder="Note about your order. e.g. special note for delivery"></textarea>
                                        
										</div>
									</div>
                                </div>
                            </div>
                            
                            <div class="col-lg-5 col-md-12 col-sm-12">
                                <div class="sec-title">
									<h1>Your Order.</h1>
									<div class="separator"></div>
								</div>
                                <div class="shop-order-box">
                                	<ul class="order-list">
                                    	<li>Prodcut<span>Total</span></li>
                                        <li>Villa ID:954<span>$65,00,000</span></li>
                                        <li>Subtotal<span class="dark">$65,00,000</span></li>
                                        <li>Shipping And Handling<span>Free Shipping</span></li>
                                        <li class="total">Total<span class="dark">$65,00,000</span></li>
                                    </ul>
                                    
                                    
                                    <!--Place Order-->
                                    <div class="place-order">
                                        <!--Payment Options-->
                                        <div class="payment-options">
                                            <ul>
                                            	<li>
                                                    <div class="radio-option">
                                                        <input type="radio" name="payment-group" id="payment-2">
                                                        <label for="payment-2"><strong>Direct Bank Transfer</strong></label>
                                                    </div>
                                                </li>
                                                <li>
                                                    <div class="radio-option">
                                                        <input type="radio" name="payment-group" id="payment-1" checked>
                                                        <label for="payment-1"><strong>Cheque Payment</strong><span class="small-text">Please send your cheque to Store Name, Store Street, Store Town, Store State / County, Store Postcode.</span></label>
                                                    </div>
                                                </li>
                                                
                                                <li>
                                                    <div class="radio-option">
                                                        <input type="radio" name="payment-group" id="payment-3">
                                                        <label for="payment-3"><strong>Paypal</strong></label>
                                                    </div>
                                                </li>
                                            </ul>
                                        </div>
                                        
                                        <button type="button" class="theme-btn btn-style-two order-btn"><span class="txt">Order place</span></button>
                                        
                                    </div>
                                    <!--End Place Order-->
                                    
                                </div>
                            </div>
                        </div>                             
                    </form>
                    
                </div>
                
            </div><!--End Billing Details-->
    	</div>
    </div>
	
	<!--Clients Section-->
    <section class="clients-section" style="background-image: url(images/background/1.jpg)">
        <div class="outer-container">
            
            <div class="sponsors-outer">
                <!--Sponsors Carousel-->
                <ul class="sponsors-carousel owl-carousel owl-theme">
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="images/clients/1.png" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="images/clients/2.png" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="images/clients/3.png" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="images/clients/4.png" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="images/clients/5.png" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="images/clients/1.png" alt=""></a></figure></li>
					<li class="slide-item"><figure class="image-box"><a href="#"><img src="images/clients/2.png" alt=""></a></figure></li>
                </ul>
            </div>
            
        </div>
    </section>
    <!--End Clients Section-->
	
	<!-- Main Footer -->
   <?php  
                include './themepart/footer.php';
   ?>
	<!-- End Main Footer -->
	
</div>  
<!--End pagewrapper-->

<!--Scroll to top-->
<div class="scroll-to-top scroll-to-target" data-target="html"><span class="fa fa-angle-up"></span></div>

<!--Search Popup-->
<div id="search-popup" class="search-popup">
	<div class="close-search theme-btn"><span class="fas fa-window-close"></span></div>
	<div class="popup-inner">
		<div class="overlay-layer"></div>
    	<div class="search-form">
        	<form method="post" action="http://ary-themes.com/html/noor_tech/dream-property/index.html">
            	<div class="form-group">
                	<fieldset>
                        <input type="search" class="form-control" name="search-input" value="" placeholder="Search Here" required >
                        <input type="submit" value="Search Now!" class="theme-btn">
                    </fieldset>
                </div>
            </form>
            
            <br>
            <h3>Recent Search Keywords</h3>
            <ul class="recent-searches">
                <li><a href="#">Business</a></li>
                <li><a href="#">Appartment</a></li>
                <li><a href="#">Flat</a></li>
                <li><a href="#">Commercial</a></li>
                <li><a href="#">Villa</a></li>
            </ul>
        
        </div>
        
    </div>
</div>

<!-- Color Palate / Color Switcher -->
<div class="color-palate">
    <div class="color-trigger">
        <i class="fas fa-cog"></i>
    </div>
    <div class="color-palate-head">
        <h6>Choose Your Color</h6>
    </div>
    <div class="various-color clearfix">
        <div class="colors-list">
            <span class="palate default-color active" data-theme-file="css/color-themes/default-theme.css"></span>
            <span class="palate yellow-color" data-theme-file="css/color-themes/yellow-theme.css"></span>
            <span class="palate olive-color" data-theme-file="css/color-themes/olive-theme.css"></span>
            <span class="palate orange-color" data-theme-file="css/color-themes/orange-theme.css"></span>
            <span class="palate purple-color" data-theme-file="css/color-themes/purple-theme.css"></span>
            <span class="palate teal-color" data-theme-file="css/color-themes/teal-theme.css"></span>
            <span class="palate brown-color" data-theme-file="css/color-themes/brown-theme.css"></span>
            <span class="palate redd-color" data-theme-file="css/color-themes/redd-color.css"></span>
        </div>
    </div>
	
	<ul class="rtl-version option-box"> <li class="rtl">RTL Version</li> <li>LTR Version</li> </ul>

    <a href="#" class="purchase-btn">Purchase now $17</a>
    
    <div class="palate-foo">
        <span>You will find much more options for colors and styling in admin panel. This color picker is used only for demonstation purposes.</span>
    </div>

</div>

<!--Scroll to top-->
<script src="js/jquery.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/jquery-ui.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.fancybox.js"></script>
<script src="js/parallax.min.js"></script>
<script src="js/isotope.js"></script>
<script src="js/jquery.paroller.min.js"></script>
<script src="js/dropzone.js"></script>
<script src="js/owl.js"></script>
<script src="js/wow.js"></script>
<script src="js/tilt.jquery.min.js"></script>
<script src="js/swiper.min.js"></script>
<script src="js/appear.js"></script>
<script src="js/script.js"></script>
<script src="js/color-settings.js"></script>

</body>

<!-- Mirrored from ary-themes.com/html/noor_tech/dream-property/checkout.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 04 Mar 2021 10:57:05 GMT -->
</html>