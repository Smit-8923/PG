<!DOCTYPE html>
<html lang="en">
<?php 
    session_start();
    if(!isset($_SESSION['logged_in'])){
        header('Location: http://localhost/user_theme/login.php');
        die();
    }
?>  
<!-- Mirrored from ary-themes.com/html/noor_tech/dream-property/index-3.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 04 Mar 2021 10:49:09 GMT -->
<head>
<meta charset="utf-8">
<title>BOOK MY PG | Home</title>
<!-- Stylesheets -->
<link href="css/bootstrap.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">
<link href="css/responsive.css" rel="stylesheet">

<!--Color Switcher Mockup-->
<link href="css/color-switcher-design.css" rel="stylesheet">
<!--Color Themes-->
<link id="theme-color-file" href="css/color-themes/default-theme.css" rel="stylesheet">

<link rel="shortcut icon" href="images/favicon.png" type="image/x-icon">
<link rel="icon" href="images/favicon.png" type="image/x-icon">

<!-- Responsive -->
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
<!--[if lt IE 9]><script src="https://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.3/html5shiv.js"></script><![endif]-->
<!--[if lt IE 9]><script src="js/respond.js"></script><![endif]-->
</head>

<body>

<div class="page-wrapper">
    <!-- Preloader -->
    <div class="preloader"></div>

  <?php
            include './themepart/header.php';
  ?>
    <!-- End Main Header -->
	
	<!--Page Title-->
    <section class="video-banner-section">
    	<!--Video-->
        <video class="bg-video" preload="auto" autoplay loop muted>
            <source src="videos/video-banner.webm" type="video/webm" />
            <source src="videos/video-banner.mp4" type="video/mp4" />
            <h3>This browser does not happen to support video</h3>
		</video>
    	<div class="auto-container">
        	<div class="inner-container">
                <h1 class="variable-text"></h1>
                <div class="text">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et sed do eiusmod tempor incididunt ut labore et.</div>
                <a href="contact.php" class="theme-btn btn-style-two"><span class="txt">Contact Now</span></a>
            </div>
        </div>
    </section>
    <!--End Page Title-->
	
	<!-- Property Section Two -->
	<section class="property-section-two">
		<div class="auto-container">
			<!--Sec Title-->
            <div class="sec-title centered">
            	<h1>About Dream Property - Real Estate  Villa</h1>
                <div class="separator"></div>
            </div>
			
			<!-- Five Columns -->
			<div class="five-col-theme">
                <div class="row clearfix">
                    
                    <!--Column-->
                    <article class="column">
                        <div class="inner-box">
                            <div class="icon"><span class="flaticon-bed"></span></div>
                            <h6 class="title">Bedrooms</h6>
                            <h5 class="count">4</h5>
                        </div>
                    </article>
                    
                    <!--Column-->
                    <article class="column">
                        <div class="inner-box">
                            <div class="icon"><span class="flaticon-dimension"></span></div>
                            <h6 class="title">Square Feet</h6>
                            <h5 class="count">4500</h5>
                        </div>
                    </article>
                    
                    <!--Column-->
                    <article class="column">
                        <div class="inner-box">
                            <div class="icon"><span class="flaticon-shower"></span></div>
                            <h6 class="title">Baths</h6>
                            <h5 class="count">3</h5>
                        </div>
                    </article>
                    
                    <!--Column-->
                    <article class="column">
                        <div class="inner-box">
                            <div class="icon"><span class="flaticon-calendar-3"></span></div>
                            <h6 class="title">Year Build</h6>
                            <h5 class="count">2019</h5>
                        </div>
                    </article>
                    
                    <!--Column-->
                    <article class="column">
                        <div class="inner-box">
                            <div class="icon"><span class="flaticon-garage-1"></span></div>
                            <h6 class="title">Car Parking</h6>
                            <h5 class="count">2</h5>
                        </div>
                    </article>
                    
                </div>
            </div>
			
		</div>
	</section>
	<!-- End Property Section Two -->
	
	<!-- Fluid Section One -->
    <section class="fluid-section-one">
    	<div class="outer-container clearfix">
        	
			<!--Content Column-->
			<div class="content-column clearfix">
				<div class="content-box">
					<!-- Sec Title -->
					<div class="sec-title">
						<h1>MyLands Details</h1>
						<div class="separator"></div>
					</div>
					
					<!-- Property Tabs -->
					<div class="property-tabs tabs-box">
					
						<!--Tab Btns-->
						<ul class="tab-btns tab-buttons clearfix">
							<li data-tab="#interior" class="tab-btn active-btn">Interior Designs</li>
							<li data-tab="#exterior" class="tab-btn">Exterior Designs</li>
							<li data-tab="#rooms" class="tab-btn">Rooms Dimenshion</li>
						</ul>
						
						<!--Tabs Container-->
						<div class="tabs-content">
                        	
                            <!-- Tab / Active Tab -->
                            <div class="tab active-tab" id="interior">
								<div class="content">
									<h3>Interior Design Details</h3>
									<div class="text">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim Lorem ipsum dolor sit amet, Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim Lorem ipsum dolor sit amet,</div>
									<div class="row clearfix">
										<div class="column col-lg-6 col-md-6 col-sm-12">
											<ul class="list-style-one">
												<li>Full Furnished</li>
												<li>Imported Marbles</li>
												<li>Water Strg : 8000/Ltr</li>
												<li>Royal Touch Paint</li>
											</ul>
										</div>
										<div class="column col-lg-6 col-md-6 col-sm-12">
											<ul class="list-style-one">
												<li>Bathroom : 02</li>
												<li>No of Floors : 02</li>
												<li>Bedrooms : 02</li>
												<li>No or Air Condition : 05</li>
											</ul>
										</div>
									</div>
								</div>
							</div>
							
							<!-- Tab Two -->
                            <div class="tab" id="exterior">
								<div class="content">
									<h3>Exterior Design Details</h3>
									<div class="text">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim Lorem ipsum dolor sit amet, Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim Lorem ipsum dolor sit amet,</div>
									<div class="row clearfix">
										<div class="column col-lg-6 col-md-6 col-sm-12">
											<ul class="list-style-one">
												<li>Full Furnished</li>
												<li>Imported Marbles</li>
												<li>Water Strg : 8000/Ltr</li>
												<li>Royal Touch Paint</li>
											</ul>
										</div>
										<div class="column col-lg-6 col-md-6 col-sm-12">
											<ul class="list-style-one">
												<li>Bathroom : 02</li>
												<li>No of Floors : 02</li>
												<li>Bedrooms : 02</li>
												<li>No or Air Condition : 05</li>
											</ul>
										</div>
									</div>
								</div>
							</div>
							
							<!-- Tab Three -->
                            <div class="tab" id="rooms">
								<div class="content">
									<h3>Rooms Dimenshions Details</h3>
									<div class="text">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim Lorem ipsum dolor sit amet, Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim Lorem ipsum dolor sit amet,</div>
									<div class="row clearfix">
										<div class="column col-lg-6 col-md-6 col-sm-12">
											<ul class="list-style-one">
												<li>Full Furnished</li>
												<li>Imported Marbles</li>
												<li>Water Strg : 8000/Ltr</li>
												<li>Royal Touch Paint</li>
											</ul>
										</div>
										<div class="column col-lg-6 col-md-6 col-sm-12">
											<ul class="list-style-one">
												<li>Bathroom : 02</li>
												<li>No of Floors : 02</li>
												<li>Bedrooms : 02</li>
												<li>No or Air Condition : 05</li>
											</ul>
										</div>
									</div>
								</div>
							</div>
						
						</div>
					</div>
					
				</div>
			</div>
			
			<!--Image Column-->
        	<div class="image-column" style="background-image: url(images/resource/video-img.jpg)">
				<div class="inner-column">
					<div class="image">
						<img src="images/resource/video-img.jpg" alt="">
					</div>
					<a href="https://www.youtube.com/watch?v=BiJtCLej4FM" class="overlay-link lightbox-image">
						<div class="icon-box">
							<span class="icon flaticon-play-button"><i class="ripple"></i></span>
						</div>
					</a>
				</div>
            </div>
            <!--End Image Column-->
			
		</div>
	</section>
	<!-- End Fluid Section One -->
	
	<!-- Counter Section -->
	<section class="counter-section-two">
		<div class="auto-container">
		
			<!-- Fact Counter -->
			<div class="fact-counter-two">
				<div class="row clearfix">

					<!--Column-->
					<div class="column counter-column col-lg-3 col-md-6 col-sm-12">
						<div class="inner wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="1500ms">
							<div class="content">
								<div class="count-outer count-box">
									<span class="count-text" data-speed="2500" data-stop="6250">0</span>
								</div>
								<h5 class="counter-title">Satisfied Clients</h5>
							</div>
						</div>
					</div>

					<!--Column-->
					<div class="column counter-column col-lg-3 col-md-6 col-sm-12">
						<div class="inner wow fadeInLeft" data-wow-delay="300ms" data-wow-duration="1500ms">
							<div class="content">
								<div class="count-outer count-box alternate">
									<span class="count-text" data-speed="3000" data-stop="350">0</span>+
								</div>
								<h5 class="counter-title">Agents Team</h5>
							</div>
						</div>
					</div>

					<!--Column-->
					<div class="column counter-column col-lg-3 col-md-6 col-sm-12">
						<div class="inner wow fadeInLeft" data-wow-delay="600ms" data-wow-duration="1500ms">
							<div class="content">
								<div class="count-outer count-box">
									<span class="count-text" data-speed="3000" data-stop="2150">0</span>
								</div>
								<h5 class="counter-title">Success Mission</h5>
							</div>
						</div>
					</div>
					
					<!--Column-->
					<div class="column counter-column col-lg-3 col-md-6 col-sm-12">
						<div class="inner wow fadeInLeft" data-wow-delay="900ms" data-wow-duration="1500ms">
							<div class="content">
								<div class="count-outer count-box">
									<span class="count-text" data-speed="2500" data-stop="64">0</span>
								</div>
								<h5 class="counter-title">Awards</h5>
							</div>
						</div>
					</div>

				</div>
			</div>
			
		</div>
	</section>
	<!-- End Counter Section -->
	
	<!-- Gallery Section -->
	<section class="gallery-section alternate">
		<div class="auto-container">
			<!--Sec Title-->
            <div class="sec-title centered">
            	<h1>Dream Property - Real Estate  Gallery</h1>
                <div class="separator"></div>
            </div>
		</div>
		
		<div class="gallery-carousel owl-carousel owl-theme">
		
			<!-- Project item -->
			<div class="gallery-item">
				<div class="image-box">
					<figure class="image"><img src="images/gallery/7.jpg" alt=""></figure>
					<div class="overlay-box">
						<div class="icon-box">
							<a href="properties-detail.html" class="link"><span class="icon fa flaticon-unlink"></span></a>
							<a href="images/gallery/7.jpg" class="link" data-fancybox="gallery-two" data-caption=""><span class="icon fa fa-expand-arrows-alt"></span></a>
							<h3><a href="properties-detail.html">France Property</a></h3>
						</div>
					</div>
				</div>
			</div>
			
			<!-- Project item -->
			<div class="gallery-item">
				<div class="image-box">
					<figure class="image"><img src="images/gallery/8.jpg" alt=""></figure>
					<div class="overlay-box">
						<div class="icon-box">
							<a href="properties-detail.html" class="link"><span class="icon fa flaticon-unlink"></span></a>
							<a href="images/gallery/8.jpg" class="link" data-fancybox="gallery-two" data-caption=""><span class="icon fa fa-expand-arrows-alt"></span></a>
							<h3><a href="properties-detail.html">France Property</a></h3>
						</div>
					</div>
				</div>
			</div>
			
			<!-- Project item -->
			<div class="gallery-item">
				<div class="image-box">
					<figure class="image"><img src="images/gallery/9.jpg" alt=""></figure>
					<div class="overlay-box">
						<div class="icon-box">
							<a href="properties-detail.html" class="link"><span class="icon fa flaticon-unlink"></span></a>
							<a href="images/gallery/9.jpg" class="link" data-fancybox="gallery-two" data-caption=""><span class="icon fa fa-expand-arrows-alt"></span></a>
							<h3><a href="properties-detail.html">France Property</a></h3>
						</div>
					</div>
				</div>
			</div>
			
			<!-- Project item -->
			<div class="gallery-item">
				<div class="image-box">
					<figure class="image"><img src="images/gallery/10.jpg" alt=""></figure>
					<div class="overlay-box">
						<div class="icon-box">
							<a href="properties-detail.html" class="link"><span class="icon fa flaticon-unlink"></span></a>
							<a href="images/gallery/10.jpg" class="link" data-fancybox="gallery-two" data-caption=""><span class="icon fa fa-expand-arrows-alt"></span></a>
							<h3><a href="properties-detail.html">France Property</a></h3>
						</div>
					</div>
				</div>
			</div>
			
			<!-- Project item -->
			<div class="gallery-item">
				<div class="image-box">
					<figure class="image"><img src="images/gallery/11.jpg" alt=""></figure>
					<div class="overlay-box">
						<div class="icon-box">
							<a href="properties-detail.html" class="link"><span class="icon fa flaticon-unlink"></span></a>
							<a href="images/gallery/11.jpg" class="link" data-fancybox="gallery-two" data-caption=""><span class="icon fa fa-expand-arrows-alt"></span></a>
							<h3><a href="properties-detail.html">France Property</a></h3>
						</div>
					</div>
				</div>
			</div>
			
			<!-- Project item -->
			<div class="gallery-item">
				<div class="image-box">
					<figure class="image"><img src="images/gallery/7.jpg" alt=""></figure>
					<div class="overlay-box">
						<div class="icon-box">
							<a href="properties-detail.html" class="link"><span class="icon fa flaticon-unlink"></span></a>
							<a href="images/gallery/7.jpg" class="link" data-fancybox="gallery-two" data-caption=""><span class="icon fa fa-expand-arrows-alt"></span></a>
							<h3><a href="properties-detail.html">France Property</a></h3>
						</div>
					</div>
				</div>
			</div>
			
			<!-- Project item -->
			<div class="gallery-item">
				<div class="image-box">
					<figure class="image"><img src="images/gallery/8.jpg" alt=""></figure>
					<div class="overlay-box">
						<div class="icon-box">
							<a href="properties-detail.html" class="link"><span class="icon fa flaticon-unlink"></span></a>
							<a href="images/gallery/8.jpg" class="link" data-fancybox="gallery-two" data-caption=""><span class="icon fa fa-expand-arrows-alt"></span></a>
							<h3><a href="properties-detail.html">France Property</a></h3>
						</div>
					</div>
				</div>
			</div>
			
			<!-- Project item -->
			<div class="gallery-item">
				<div class="image-box">
					<figure class="image"><img src="images/gallery/9.jpg" alt=""></figure>
					<div class="overlay-box">
						<div class="icon-box">
							<a href="properties-detail.html" class="link"><span class="icon fa flaticon-unlink"></span></a>
							<a href="images/gallery/9.jpg" class="link" data-fancybox="gallery-two" data-caption=""><span class="icon fa fa-expand-arrows-alt"></span></a>
							<h3><a href="properties-detail.html">France Property</a></h3>
						</div>
					</div>
				</div>
			</div>
			
			<!-- Project item -->
			<div class="gallery-item">
				<div class="image-box">
					<figure class="image"><img src="images/gallery/10.jpg" alt=""></figure>
					<div class="overlay-box">
						<div class="icon-box">
							<a href="properties-detail.html" class="link"><span class="icon fa flaticon-unlink"></span></a>
							<a href="images/gallery/10.jpg" class="link" data-fancybox="gallery-two" data-caption=""><span class="icon fa fa-expand-arrows-alt"></span></a>
							<h3><a href="properties-detail.html">France Property</a></h3>
						</div>
					</div>
				</div>
			</div>
			
			<!-- Project item -->
			<div class="gallery-item">
				<div class="image-box">
					<figure class="image"><img src="images/gallery/11.jpg" alt=""></figure>
					<div class="overlay-box">
						<div class="icon-box">
							<a href="properties-detail.html" class="link"><span class="icon fa flaticon-unlink"></span></a>
							<a href="images/gallery/11.jpg" class="link" data-fancybox="gallery-two" data-caption=""><span class="icon fa fa-expand-arrows-alt"></span></a>
							<h3><a href="properties-detail.html">France Property</a></h3>
						</div>
					</div>
				</div>
			</div>
			
		</div>
	</section>
	<!-- End Gallery Section -->
	
	<!-- Faq Action -->
    <section class="faq-section">
        <div class="auto-container">
            <div class="sec-title centered">
                <h1>Faq's</h1>
				<div class="separator"></div>
            </div>
			
			<div class="row clearfix">
            	
                <!--Column-->
            	<div class="column col-lg-4 col-md-6 col-sm-12">
                	<!--Faq Block-->
                    <div class="faq-block">
                    	<div class="question"><h4>How can you contact us ?</h4></div>
                        <div class="answer">
                        	<p>Lorem ipsum dolor sit amet, consectetuer  a the adipiscing elit. Aenean commodo ligulai dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient.</p>
                        </div>
                    </div>
                    
                    <!--Faq Block-->
                    <div class="faq-block">
                    	<div class="question"><h4>How can we reached at you ?</h4></div>
                        <div class="answer">
                        	<p>Lorem ipsum dolor sit amet, consectetuer  a the adipiscing elit. Aenean commodo ligulai dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient.</p>
                        </div>
                    </div>
                    
                </div>
                
                
                <!--Column-->
            	<div class="column col-lg-4 col-md-6 col-sm-12">
                	<!--Faq Block-->
                    <div class="faq-block">
                    	<div class="question"><h4>Dream Property - Real Estate  service all over the world</h4></div>
                        <div class="answer">
                        	<p>Lorem ipsum dolor sit amet, consectetuer  a the adipiscing elit. Aenean commodo ligulai dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient.</p>
                        </div>
                    </div>
                    
                    <!--Faq Block-->
                    <div class="faq-block">
                    	<div class="question"><h4>There is No Fraud in Dream Property - Real Estate ?</h4></div>
                        <div class="answer">
                        	<p>Lorem ipsum dolor sit amet, consectetuer  a the adipiscing elit. Aenean commodo ligulai dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient.</p>
                        </div>
                    </div>
                    
                </div>
                
                
                <!--Column-->
            	<div class="column col-lg-4 col-md-6 col-sm-12">
                	<!--Faq Block-->
                    <div class="faq-block">
                    	<div class="question"><h4>100% clients Satisfactions?</h4></div>
                        <div class="answer">
                        	<p>Lorem ipsum dolor sit amet, consectetuer  a the adipiscing elit. Aenean commodo ligulai dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient.</p>
                        </div>
                    </div>
                    
                    <!--Faq Block-->
                    <div class="faq-block">
                    	<div class="question"><h4>If you find problem than quoted ?</h4></div>
                        <div class="answer">
                        	<p>Lorem ipsum dolor sit amet, consectetuer  a the adipiscing elit. Aenean commodo ligulai dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient.</p>
                        </div>
                    </div>
                    
                </div>
				
			</div>
			
		</div>
	</section>
	<!-- End Faq Action -->
	
	<!-- Appointment Section -->
	<section class="appointment-section">
		<div class="auto-container">
			<div class="sec-title centered">
                <h1>Book Appointment</h1>
				<div class="separator"></div>
            </div>
			
			<div class="appointment-carousel owl-carousel owl-theme">
								
				<!-- Calender Block -->
				<div class="calender-block">
					<div class="block-outer">
						<div class="inner-box">
							<!-- Days Boxed -->
							<div class="days-boxed">
								<div class="clearfix">
									<div class="day-date"><strong>Mon</strong>10 Oct 2018</div>
									<div class="day-date"><strong>tue</strong>11 Oct 2018</div>
									<div class="day-date"><strong>wed</strong>12 Oct 2018</div>
									<div class="day-date"><strong>thu</strong>13 Oct 2018</div>
									<div class="day-date"><strong>fri</strong>14 Oct 2018</div>
								</div>
							</div>
							
							<!-- Time Boxed -->
							<div class="time-boxed">
								<div class="clearfix">
									<div class="time">08:30</div>
									<div class="time">08:30</div>
									<div class="time">09:00</div>
									<div class="time">08:30</div>
									<div class="time">08:30</div>
									<div class="time">09:00</div>
									<div class="time">09:00</div>
									<div class="time">09:30</div>
									<div class="time">09:00</div>
									<div class="time">09:00</div>
									<div class="time">09:30</div>
									<div class="time">09:30</div>
									<div class="time">10:00</div>
									<div class="time">09:30</div>
									<div class="time">09:30</div>
									<div class="time">10:00</div>
									<div class="time">10:00</div>
									<div class="time">10:30</div>
									<div class="time">10:00</div>
									<div class="time">10:00</div>
								</div>
							</div>
							
							<!-- More Boxed -->
							<div class="more-boxed">
								<div class="clearfix">
									<div class="more">more...</div>
									<div class="more">more...</div>
									<div class="more">more...</div>
									<div class="more">more...</div>
									<div class="more">more...</div>
								</div>
							</div>
							
						</div>
						<!-- Button Box -->
						<div class="button-box">
							<a href="appointment.html" class="theme-btn btn-style-two"><span class="txt">Appointment Now</span></a>
							<a href="contact.html" class="theme-btn btn-style-two"><span class="txt">Contact us</span></a>
						</div>
					</div>
				</div>
				
				<!-- Calender Block -->
				<div class="calender-block">
					<div class="block-outer">
						<div class="inner-box">
							<!-- Days Boxed -->
							<div class="days-boxed">
								<div class="clearfix">
									<div class="day-date"><strong>Mon</strong>10 Oct 2018</div>
									<div class="day-date"><strong>tue</strong>11 Oct 2018</div>
									<div class="day-date"><strong>wed</strong>12 Oct 2018</div>
									<div class="day-date"><strong>thu</strong>13 Oct 2018</div>
									<div class="day-date"><strong>fri</strong>14 Oct 2018</div>
								</div>
							</div>
							
							<!-- Time Boxed -->
							<div class="time-boxed">
								<div class="clearfix">
									<div class="time">08:30</div>
									<div class="time">08:30</div>
									<div class="time">09:00</div>
									<div class="time">08:30</div>
									<div class="time">08:30</div>
									<div class="time">09:00</div>
									<div class="time">09:00</div>
									<div class="time">09:30</div>
									<div class="time">09:00</div>
									<div class="time">09:00</div>
									<div class="time">09:30</div>
									<div class="time">09:30</div>
									<div class="time">10:00</div>
									<div class="time">09:30</div>
									<div class="time">09:30</div>
									<div class="time">10:00</div>
									<div class="time">10:00</div>
									<div class="time">10:30</div>
									<div class="time">10:00</div>
									<div class="time">10:00</div>
								</div>
							</div>
							
							<!-- More Boxed -->
							<div class="more-boxed">
								<div class="clearfix">
									<div class="more">more...</div>
									<div class="more">more...</div>
									<div class="more">more...</div>
									<div class="more">more...</div>
									<div class="more">more...</div>
								</div>
							</div>
							
						</div>
						<!-- Button Box -->
						<div class="button-box">
							<a href="appointment.html" class="theme-btn btn-style-two"><span class="txt">Appointment Now</span></a>
							<a href="contact.php" class="theme-btn btn-style-two"><span class="txt">Contact us</span></a>
						</div>
					</div>
				</div>
				
				<!-- Calender Block -->
				<div class="calender-block">
					<div class="block-outer">
						<div class="inner-box">
							<!-- Days Boxed -->
							<div class="days-boxed">
								<div class="clearfix">
									<div class="day-date"><strong>Mon</strong>10 Oct 2018</div>
									<div class="day-date"><strong>tue</strong>11 Oct 2018</div>
									<div class="day-date"><strong>wed</strong>12 Oct 2018</div>
									<div class="day-date"><strong>thu</strong>13 Oct 2018</div>
									<div class="day-date"><strong>fri</strong>14 Oct 2018</div>
								</div>
							</div>
							
							<!-- Time Boxed -->
							<div class="time-boxed">
								<div class="clearfix">
									<div class="time">08:30</div>
									<div class="time">08:30</div>
									<div class="time">09:00</div>
									<div class="time">08:30</div>
									<div class="time">08:30</div>
									<div class="time">09:00</div>
									<div class="time">09:00</div>
									<div class="time">09:30</div>
									<div class="time">09:00</div>
									<div class="time">09:00</div>
									<div class="time">09:30</div>
									<div class="time">09:30</div>
									<div class="time">10:00</div>
									<div class="time">09:30</div>
									<div class="time">09:30</div>
									<div class="time">10:00</div>
									<div class="time">10:00</div>
									<div class="time">10:30</div>
									<div class="time">10:00</div>
									<div class="time">10:00</div>
								</div>
							</div>
							
							<!-- More Boxed -->
							<div class="more-boxed">
								<div class="clearfix">
									<div class="more">more...</div>
									<div class="more">more...</div>
									<div class="more">more...</div>
									<div class="more">more...</div>
									<div class="more">more...</div>
								</div>
							</div>
							
						</div>
						<!-- Button Box -->
						<div class="button-box">
							<a href="appointment.html" class="theme-btn btn-style-two"><span class="txt">Appointment Now</span></a>
							<a href="contact.html" class="theme-btn btn-style-two"><span class="txt">Contact us</span></a>
						</div>
					</div>
				</div>
				
			</div>
			
			<!-- Booking Form Section -->
			<div class="booking-form-section">
			
				<!-- Sec Title -->
				<div class="sec-title centered">
					<h1>Booking Form</h1>
					<div class="separator"></div>
				</div>
				
				<!--Default Form-->
				<div class="default-form">
					<form method="post" action="http://ary-themes.com/html/noor_tech/dream-property/contact.html">
						<div class="row clearfix">
							<div class="column col-lg-6 col-md-12 col-sm-12">
							
								<div class="form-group">
									<input type="text" name="username" placeholder="Name*" required>
								</div>
								
								<div class="form-group">
									<input type="email" name="email" placeholder="Email *" required>
								</div>
								
								<div class="form-group">
									<input type="text" name="phone" placeholder="Phone*" required>
								</div>
								
								<!-- Form Group -->
								<div class="form-group">
									<select class="custom-select-box">
										<option>Country</option>
										<option>USA</option>
										<option>Canada</option>
										<option>France</option>
										<option>Italy</option>
										<option>UAE</option>
									</select>
								</div>
								
							</div>
							
							<div class="column col-lg-6 col-md-12 col-sm-12">
								<div class="form-group">
									<textarea name="message" placeholder="Message*"></textarea>
								</div>
							</div>
							<div class="form-group text-center col-lg-12 col-md-12 col-sm-12">
								<button class="theme-btn btn-style-two" type="submit" name="submit-form"><span class="txt">Submit Now</span></button>
							</div>
						</div>
						
					</form>
				</div>
				
			</div>
			
		</div>
	</section>
	<!-- End Appointment Section -->
	
	<!-- Recent Properties Section -->
    <section class="recent-properties-section">
        <div class="auto-container">
            <div class="sec-title centered">
                <h1>Dream Property Properties</h1>
				<div class="separator"></div>
            </div>
			
			<div class="row clearfix">
				
				<!-- Property Block -->
				<div class="property-block-two col-lg-6 col-md-12 col-sm-12">
					<div class="inner-box">
						<div class="clearfix">
							<div class="image-box col-lg-6 col-md-12 col-sm-12">
								<figure class="image"><img src="images/resource/property-4.jpg" alt=""></figure>
								<span class="for">FOR SALE</span>
								<span class="featured">FEATURED</span>
							</div>
							<div class="lower-content col-lg-6 col-md-12 col-sm-12">
								<ul class="tags">
									<li><a href="properties-detail.html">Apartment</a>,</li>
									<li><a href="properties-detail.html">Bar</a>,</li>
									<li><a href="properties-detail.html">House</a></li>
								</ul>
								<h5><a href="properties-detail.html">Single Flat Burj Al-Arab.</a></h5>
								<div class="lucation"><i class="la la-map-marker"></i> Orland Park, IL 785, Chicago, USA</div>
								<ul class="property-info clearfix">
									<li><i class="flaticon-dimension"></i> 356 Sq-Ft</li>
									<li><i class="flaticon-bed"></i> 1 Bedrooms</li>
									<li><i class="flaticon-garage-1"></i> 1 Garage</li>
									<li><i class="flaticon-toilet"></i> 2 Bathroom</li>
								</ul>
								<div class="property-price clearfix">
									<div class="read-more"><a href="properties-detail.html" class="theme-btn">More Detail</a></div>
									<div class="price">$ 14,95,000</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				
				<!-- Property Block -->
				<div class="property-block-two col-lg-6 col-md-12 col-sm-12">
					<div class="inner-box">
						<div class="clearfix">
							<div class="image-box col-lg-6 col-md-12 col-sm-12">
								<figure class="image"><img src="images/resource/property-5.jpg" alt=""></figure>
								<span class="for">FOR Rent</span>
								<span class="featured">FEATURED</span>
							</div>
							<div class="lower-content col-lg-6 col-md-12 col-sm-12">
								<ul class="tags">
									<li><a href="properties-detail.html">Apartment</a>,</li>
									<li><a href="properties-detail.html">Bar</a>,</li>
									<li><a href="properties-detail.html">House</a></li>
								</ul>
								<h5><a href="properties-detail.html">California New Villas.</a></h5>
								<div class="lucation"><i class="la la-map-marker"></i> Makine Park, PM 700, Califonia</div>
								<ul class="property-info clearfix">
									<li><i class="flaticon-dimension"></i> 356 Sq-Ft</li>
									<li><i class="flaticon-bed"></i> 3 Bedrooms</li>
									<li><i class="flaticon-garage-1"></i> 1 Garage</li>
									<li><i class="flaticon-toilet"></i> 3 Bathroom</li>
								</ul>
								<div class="property-price clearfix">
									<div class="read-more"><a href="properties-detail.html" class="theme-btn">More Detail</a></div>
									<div class="price">$ 10,00,000</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				
				<!-- Property Block -->
				<div class="property-block-two col-lg-6 col-md-12 col-sm-12">
					<div class="inner-box">
						<div class="clearfix">
							<div class="image-box col-lg-6 col-md-12 col-sm-12">
								<figure class="image"><img src="images/resource/property-6.jpg" alt=""></figure>
								<span class="for">Available</span>
							</div>
							<div class="lower-content col-lg-6 col-md-12 col-sm-12">
								<ul class="tags">
									<li><a href="properties-detail.html">Apartment</a>,</li>
									<li><a href="properties-detail.html">Bar</a>,</li>
									<li><a href="properties-detail.html">House</a></li>
								</ul>
								<h5><a href="properties-detail.html">Apartment 1243, Sydney.</a></h5>
								<div class="lucation"><i class="la la-map-marker"></i> viewport Point, 987456, Australia.</div>
								<ul class="property-info clearfix">
									<li><i class="flaticon-dimension"></i> 356 Sq-Ft</li>
									<li><i class="flaticon-bed"></i> 2 Bedrooms</li>
									<li><i class="flaticon-garage-1"></i> 2 Garage</li>
									<li><i class="flaticon-toilet"></i> 1 Bathroom</li>
								</ul>
								<div class="property-price clearfix">
									<div class="read-more"><a href="properties-detail.html" class="theme-btn">More Detail</a></div>
									<div class="price">$ 24,95,000</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				
				<!-- Property Block -->
				<div class="property-block-two col-lg-6 col-md-12 col-sm-12">
					<div class="inner-box">
						<div class="clearfix">
							<div class="image-box col-lg-6 col-md-12 col-sm-12">
								<figure class="image"><img src="images/resource/property-7.jpg" alt=""></figure>
								<span class="for sold">Sold Done</span>
							</div>
							<div class="lower-content col-lg-6 col-md-12 col-sm-12">
								<ul class="tags">
									<li><a href="properties-detail.html">Apartment</a>,</li>
									<li><a href="properties-detail.html">Bar</a>,</li>
									<li><a href="properties-detail.html">House</a></li>
								</ul>
								<h5><a href="properties-detail.html">Commercial New Building.</a></h5>
								<div class="lucation"><i class="la la-map-marker"></i>Gold Land Commercial Dubai</div>
								<ul class="property-info clearfix">
									<li><i class="flaticon-dimension"></i> 356 Sq-Ft</li>
									<li><i class="flaticon-bed"></i> 1 Bedrooms</li>
									<li><i class="flaticon-garage-1"></i> 1 Garage</li>
									<li><i class="flaticon-toilet"></i> 2 Bathroom</li>
								</ul>
								<div class="property-price clearfix">
									<div class="read-more"><a href="properties-detail.html" class="theme-btn">More Detail</a></div>
									<div class="price">$ 14,95,000</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				
			</div>
		</div>
	</section>
	<!-- End Recent Properties Section -->
	
	<!-- Call To Action -->
    <section class="call-to-action">
        <div class="auto-container">
            <div class="sec-title light centered">
                <h1>Make Appointment Now</h1>
				<div class="separator"></div>
            </div>
			<span class="number"><a href="tel:999-000-9999">999 000 9999</a></span>
			<div class="text">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et <br> dolore magna aliqua. Ut enim ad minim veniam.</div>
            <div class="btn-box"><a href="contact.html" class="theme-btn btn-style-three"><span class="txt">Appointment</span></a></div>
        </div>
    </section>
    <!--End Call To Action -->
	
	<!--Clients Section-->
    <section class="clients-section" style="background-image: url(images/background/1.jpg)">
        <div class="outer-container">
            
            <div class="sponsors-outer">
                <!--Sponsors Carousel-->
                <ul class="sponsors-carousel owl-carousel owl-theme">
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="images/clients/1.png" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="images/clients/2.png" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="images/clients/3.png" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="images/clients/4.png" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="images/clients/5.png" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="images/clients/1.png" alt=""></a></figure></li>
					<li class="slide-item"><figure class="image-box"><a href="#"><img src="images/clients/2.png" alt=""></a></figure></li>
                </ul>
            </div>
            
        </div>
    </section>
    <!--End Clients Section-->
	
	<!-- Footer Style Three -->
   <?php   
            include './themepart/footer.php';
   ?>
	<!-- End Footer Style Three -->
	
</div>  
<!--End pagewrapper-->

<!--Scroll to top-->
<div class="scroll-to-top scroll-to-target" data-target="html"><span class="fa fa-angle-up"></span></div>

<!--Search Popup-->
<div id="search-popup" class="search-popup">
	<div class="close-search theme-btn"><span class="fas fa-window-close"></span></div>
	<div class="popup-inner">
		<div class="overlay-layer"></div>
    	<div class="search-form">
        	<form method="post" action="http://ary-themes.com/html/noor_tech/dream-property/index.html">
            	<div class="form-group">
                	<fieldset>
                        <input type="search" class="form-control" name="search-input" value="" placeholder="Search Here" required >
                        <input type="submit" value="Search Now!" class="theme-btn">
                    </fieldset>
                </div>
            </form>
            
            <br>
            <h3>Recent Search Keywords</h3>
            <ul class="recent-searches">
                <li><a href="#">Business</a></li>
                <li><a href="#">Appartment</a></li>
                <li><a href="#">Flat</a></li>
                <li><a href="#">Commercial</a></li>
                <li><a href="#">Villa</a></li>
            </ul>
        
        </div>
        
    </div>
</div>

<!-- sidebar cart item -->
<div class="xs-sidebar-group info-group">
	<div class="xs-overlay xs-bg-black"></div>
	<div class="xs-sidebar-widget">
		<div class="sidebar-widget-container">
			<div class="widget-heading">
				<a href="#" class="close-side-widget">
					X
				</a>
			</div>
			<div class="sidebar-textwidget">
				
				<!-- Sidebar Info Content -->
            <div class="sidebar-info-contents">
				<div class="content-inner">
					<div class="logo">
						<a href="index.html"><img src="images/pg_logo.png" alt="" /></a>
					</div>
					<div class="content-box">
						<h2>About Us</h2>
						<p class="text">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum suspendisse ultrices gravida.</p>
						<a href="contact.html" class="theme-btn btn-style-two"><span class="txt">Contact Us</span></a>
					</div>
					<div class="contact-info">
						<h2>Contact Info</h2>
						<ul class="list-style-two">
							<li><span class="icon flaticon-map"></span>Chicago 12, Melborne City, USA</li>
							<li><span class="icon flaticon-telephone"></span>(111) 000-000-0000</li>
							<li><span class="icon flaticon-message-1"></span>example@gmail.com</li>
							<li><span class="icon flaticon-timetable"></span>Week Days: 09.00 to 18.00 Sunday: Closed</li>
						</ul>
					</div>
					<!-- Social Box -->
					<ul class="social-box">
						<li class="facebook"><a href="#" class="fab fa-facebook-f"></a></li>
						<li class="twitter"><a href="#" class="fab fa-twitter"></a></li>
						<li class="linkedin"><a href="#" class="fab fa-linkedin-in"></a></li>
						<li class="instagram"><a href="#" class="fab fa-instagram"></a></li>
						<li class="youtube"><a href="#" class="fab fa-youtube"></a></li>
					</ul>
				</div>
			</div>
				
			</div>
		</div>
	</div>
</div>
<!-- END sidebar widget item -->

<!-- Color Palate / Color Switcher -->
<div class="color-palate">
    <div class="color-trigger">
        <i class="fas fa-cog"></i>
    </div>
    <div class="color-palate-head">
        <h6>Choose Your Color</h6>
    </div>
    <div class="various-color clearfix">
        <div class="colors-list">
            <span class="palate default-color active" data-theme-file="css/color-themes/default-theme.css"></span>
            <span class="palate yellow-color" data-theme-file="css/color-themes/yellow-theme.css"></span>
            <span class="palate olive-color" data-theme-file="css/color-themes/olive-theme.css"></span>
            <span class="palate orange-color" data-theme-file="css/color-themes/orange-theme.css"></span>
            <span class="palate purple-color" data-theme-file="css/color-themes/purple-theme.css"></span>
            <span class="palate teal-color" data-theme-file="css/color-themes/teal-theme.css"></span>
            <span class="palate brown-color" data-theme-file="css/color-themes/brown-theme.css"></span>
            <span class="palate redd-color" data-theme-file="css/color-themes/redd-color.css"></span>
        </div>
    </div>
	
	<ul class="rtl-version option-box"> <li class="rtl">RTL Version</li> <li>LTR Version</li> </ul>

    <a href="#" class="purchase-btn">Purchase now $17</a>
    
    <div class="palate-foo">
        <span>You will find much more options for colors and styling in admin panel. This color picker is used only for demonstation purposes.</span>
    </div>

</div>

<!--Scroll to top-->
<script src="js/jquery.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/typeit.js"></script>
<script src="js/jquery-ui.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.fancybox.js"></script>
<script src="js/parallax.min.js"></script>
<script src="js/jquery.paroller.min.js"></script>
<script src="js/owl.js"></script>
<script src="js/wow.js"></script>
<script src="js/nav-tool.js"></script>
<script src="js/dropzone.js"></script>
<script src="js/jquery.magnific-popup.min.js"></script>
<script src="js/main.js"></script>
<script src="js/swiper.min.js"></script>
<script src="js/appear.js"></script>
<script src="js/script.js"></script>
<script src="js/color-settings.js"></script>

</body>

<!-- Mirrored from ary-themes.com/html/noor_tech/dream-property/index-3.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 04 Mar 2021 10:51:03 GMT -->
</html>