
<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from ary-themes.com/html/noor_tech/dream-property/submit-property.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 04 Mar 2021 10:53:32 GMT -->
<head>
<meta charset="utf-8">
<title>BOOK MY PG  | Submit Property</title>
<!-- Stylesheets -->
<link href="css/bootstrap.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">
<link href="css/responsive.css" rel="stylesheet">

<!--Color Switcher Mockup-->
<link href="css/color-switcher-design.css" rel="stylesheet">
<!--Color Themes-->
<link id="theme-color-file" href="css/color-themes/default-theme.css" rel="stylesheet">

<link rel="shortcut icon" href="images/favicon.png" type="image/x-icon">
<link rel="icon" href="images/favicon.png" type="image/x-icon">

<!-- Responsive -->
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
<!--[if lt IE 9]><script src="https://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.3/html5shiv.js"></script><![endif]-->
<!--[if lt IE 9]><script src="js/respond.js"></script><![endif]-->
</head>

<body>

<div class="page-wrapper">
    <!-- Preloader -->
    <div class="preloader"></div>

    <?php
      
      include './themepart/header.php';  
?>
    <!-- End Main Header -->
	
	<!-- Page Title -->
    <section class="page-title" style="background-image:url(images/background/2.jpg);">
    	<div class="auto-container">
        	<div class="inner-box">
                <h1>Submit Property</h1>
                <div class="bread-crumb"><a href="index.html">Home &nbsp; /</a> <i class="current">Submit Property</i></div>
            </div>
        </div>
    </section>
	<!-- End Page Title -->
	
	<!-- Submit Property Section -->
	<section class="submit-property-section">
		<div class="auto-container">
		
			<!-- Submit Property Header -->
			<div class="submit-property-header-section">
				<div class="row clearfix">
					<!-- Column -->
					<div class="column col-lg-6 col-md-12 col-sm-12">
						<h1>Submit Property</h1>
					</div>
					<!-- Column -->
					<div class="column col-lg-6 col-md-12 col-sm-12">
						<ul class="dashboard-nav">
							<li><a href="index.html">Index</a></li>
							<li><a href="messages.html">Messages</a></li>
							<li><a href="booking.html">Booking</a></li>
							<li><a href="dashboard.html">Dashboard</a></li>
							<li class="active"><a href="submit-property.html">Submit Property</a></li>
						</ul>
					</div>
				</div>
			</div>
			
			<!-- Submit Property Section -->
			<div class="dashboard-property-section">
				<h2>Basic Information</h2>
				
				<!-- Property Search Form -->
				<div class="property-search-form">
					<form method="post" action="http://ary-themes.com/html/noor_tech/dream-property/index.html">
						<div class="row">
						
							<!-- Form Group -->
							<div class="form-group col-lg-4 col-md-4 col-sm-12">
								<label>Name</label>
								<input type="text" name="text" placeholder="Name" required>
							</div>
							
							<!-- Form Group -->
							<div class="form-group col-lg-4 col-md-4 col-sm-12">
								<label>Email</label>
								<input type="mail" name="email" placeholder="Email" required>
							</div>
							
							<!-- Form Group -->
							<div class="form-group col-lg-4 col-md-4 col-sm-12">
								<label>Phone</label>
								<input type="text" name="phone" placeholder="Phone" required>
							</div>
							
							<!-- Form Group -->
							<div class="form-group col-lg-3 col-md-6 col-sm-12">
								<label>Property Title</label>
								<input type="text" name="text" placeholder="Property Title" required>
							</div>
							
							<!-- Form Group -->
							<div class="form-group col-lg-3 col-md-6 col-sm-12">
								<label>Property Type</label>
								<select class="custom-select-box">
									<option>Apartment</option>
									<option>Commercial</option>
									<option>House</option>
									<option>Villa</option>
									<option>Residential</option>
								</select>
							</div>
							
							<!-- Form Group -->
							<div class="form-group col-lg-3 col-md-6 col-sm-12">
								<label>Country</label>
								<select class="custom-select-box">
									<option>USA</option>
									<option>London</option>
									<option>France</option>
									<option>UAE</option>
									<option>Australia</option>
								</select>
							</div>
							
							<!-- Form Group -->
							<div class="form-group col-lg-3 col-md-6 col-sm-12">
								<label>Status</label>
								<select class="custom-select-box">
									<option>For Rent</option>
									<option>For Sale</option>
								</select>
							</div>
							
							<!-- Form Group -->
							<div class="form-group col-lg-3 col-md-6 col-sm-12">
								<label>Area</label>
								<input type="text" name="text" placeholder="Square Ft" required>
							</div>

							<!-- Form Group -->
							<div class="form-group col-lg-3 col-md-6 col-sm-12">
								<label>Bedrooms</label>
								<select class="custom-select-box">
									<option>01</option>
									<option>02</option>
									<option>03</option>
									<option>04</option>
									<option>05</option>
								</select>
							</div>
							
							<!-- Form Group -->
							<div class="form-group col-lg-3 col-md-6 col-sm-12">
								<label>Car Space</label>
								<select class="custom-select-box">
									<option>01</option>
									<option>02</option>
									<option>03</option>
									<option>04</option>
									<option>05</option>
								</select>
							</div>
							
							<!-- Form Group -->
							<div class="form-group col-lg-3 col-md-6 col-sm-12">
								<label>Attach Washroom</label>
								<select class="custom-select-box">
									<option>01</option>
									<option>02</option>
									<option>03</option>
									<option>04</option>
									<option>05</option>
								</select>
							</div>
							
							<!-- Form Group -->
							<div class="form-group col-lg-12 col-md-12 col-sm-12">
								<h2>Address</h2>
							</div>
							
							<!-- Form Group -->
							<div class="form-group col-lg-3 col-md-6 col-sm-12">
								<label>State</label>
								<select class="custom-select-box">
									<option>New York</option>
									<option>California</option>
									<option>Sydney</option>
									<option>France</option>
									<option>Dubai</option>
								</select>
							</div>
							
							<!-- Form Group -->
							<div class="form-group col-lg-3 col-md-6 col-sm-12">
								<label>Postal Code</label>
								<input type="text" name="text" placeholder="Postal Code" required>
							</div>
							
							<!-- Form Group -->
							<div class="form-group col-lg-6 col-md-6 col-sm-12">
								<label>Address</label>
								<input type="text" name="text" placeholder="Address" required>
							</div>
							
							<!-- Form Group -->
							<div class="form-group col-lg-12 col-md-12 col-sm-12">
								<h2>Attach File</h2>
							</div>
							
							<div class="form-group col-lg-12 col-md-12 col-sm-12">
								<div id="myDropZone" class="dropzone dropzone-design">
									<div class="dz-default dz-message"><span>Drop files here to upload</span></div>
								</div>
							</div>
							
							<!-- Form Group -->
							<div class="form-group col-lg-12 col-md-12 col-sm-12">
								<h2>Comment Information</h2>
							</div>
							
							<!-- Form Group -->
							<div class="form-group col-lg-12 col-md-12 col-sm-12">
								<label>Comments</label>
								<textarea class="message"></textarea>
							</div>
							
							<!-- Form Group -->
							<div class="form-group col-lg-12 col-md-12 col-sm-12">
								<h2>Featured Information</h2>
							</div>
							
							<div class="form-group col-lg-3 col-md-6 col-sm-12 ">
								<div class="check-box">
									<input type="checkbox" name="shipping-option" id="service-1"> 
									<label for="service-1">Air Conditioning</label>
								</div>
							</div>

							<div class="form-group col-lg-3 col-md-6 col-sm-12 ">
								<div class="check-box">
									<input type="checkbox" name="shipping-option" id="service-2"> 
									<label for="service-2">Alarm System</label>
								</div>
							</div>

							<div class="form-group col-lg-3 col-md-6 col-sm-12 ">
								<div class="check-box">
									<input type="checkbox" name="shipping-option" id="service-3"> 
									<label for="service-3">Doorman</label>
								</div>
							</div>

							<div class="form-group col-lg-3 col-md-6 col-sm-12 ">
								<div class="check-box">
									<input type="checkbox" name="shipping-option" id="service-4"> 
									<label for="service-4">Fireplace</label>
								</div>
							</div>

							<div class="form-group col-lg-3 col-md-6 col-sm-12 ">
								<div class="check-box">
									<input type="checkbox" name="shipping-option" id="service-5"> 
									<label for="service-5">Garden</label>
								</div>
							</div>

							<div class="form-group col-lg-3 col-md-6 col-sm-12 ">
								<div class="check-box">
									<input type="checkbox" name="shipping-option" id="service-6"> 
									<label for="service-6">Heating System</label>
								</div>
							</div>

							<div class="form-group col-lg-3 col-md-6 col-sm-12 ">
								<div class="check-box">
									<input type="checkbox" name="shipping-option" id="service-7"> 
									<label for="service-7">High Ceiling</label>
								</div>
							</div>

							<div class="form-group col-lg-3 col-md-6 col-sm-12 ">
								<div class="check-box">
									<input type="checkbox" name="shipping-option" id="service-8"> 
									<label for="service-8">Car Parking</label>
								</div>
							</div>

							<div class="form-group col-lg-3 col-md-6 col-sm-12 ">
								<div class="check-box">
									<input type="checkbox" name="shipping-option" id="service-9"> 
									<label for="service-9">Swimming Pool</label>
								</div>
							</div>

							<div class="form-group col-lg-3 col-md-6 col-sm-12 ">
								<div class="check-box">
									<input type="checkbox" name="shipping-option" id="service-10"> 
									<label for="service-10">Laundry Room</label>
								</div>
							</div>

							<div class="form-group col-lg-3 col-md-6 col-sm-12 ">
								<div class="check-box">
									<input type="checkbox" name="shipping-option" id="service-11"> 
									<label for="service-11">Places to seat</label>
								</div>
							</div>

							<div class="form-group col-lg-3 col-md-6 col-sm-12 ">
								<div class="check-box">
									<input type="checkbox" name="shipping-option" id="service-12"> 
									<label for="service-12">Window Covering</label>
								</div>
							</div>
							
							<!-- Form Group -->
							<div class="form-group col-lg-12 col-md-12 col-sm-12">
								<button type="submit" class="theme-btn btn-style-two"><span class="txt">Submit Now</span></button>
							</div>
							
						</div>
					</form>
				</div>
				
			</div>
			
		</div>
	</section>
	<!-- End Submit Property Section -->
	
	<!--Newsleter Section-->
    <section class="newsletter-section" style="background-image:url(images/background/1.jpg)">
    	<div class="auto-container">
        	<div class="inner-container">
            	<div class="row clearfix">
                	
                    <!--Title Column-->
                    <div class="title-column col-lg-5 col-md-12 col-sm-12">
                    	<div class="inner-column">
                        	<div class="icon-box">
                            	<span class="icon flaticon-door-knob"></span>
                            </div>
                            <h4>Newsletter Subscription</h4>
                            <div class="title">Get latest news & updates</div>
                        </div>
                    </div>
                    
                    <!--Form Column-->
                    <div class="form-column col-lg-7 col-md-12 col-sm-12">
                    	<div class="inner-column">
                        	
                            <!--Subscribe Form-->
                            <div class="subscribe-form">
                                <form method="post" action="http://ary-themes.com/html/noor_tech/dream-property/contact.html">
                                    <div class="form-group">
                                        <input type="email" name="email" value="" placeholder="Email Address" required>
                                        <button type="submit" class="submit-btn">Submit Now</button>
                                    </div>
                                </form>
                            </div>
                            
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
    </section>
    <!--End Newsleter Section-->
	
	<!--Main Footer-->
    <?php
      
      include './themepart/footer.php';  
?>
	
</div>
<!--End pagewrapper-->

<!--Scroll to top-->
<div class="scroll-to-top scroll-to-target" data-target="html"><span class="fa fa-angle-up"></span></div>

<!--Search Popup-->
<div id="search-popup" class="search-popup">
	<div class="close-search theme-btn"><span class="fas fa-window-close"></span></div>
	<div class="popup-inner">
		<div class="overlay-layer"></div>
    	<div class="search-form">
        	<form method="post" action="http://ary-themes.com/html/noor_tech/dream-property/index.html">
            	<div class="form-group">
                	<fieldset>
                        <input type="search" class="form-control" name="search-input" value="" placeholder="Search Here" required >
                        <input type="submit" value="Search Now!" class="theme-btn">
                    </fieldset>
                </div>
            </form>
            
            <br>
            <h3>Recent Search Keywords</h3>
            <ul class="recent-searches">
                <li><a href="#">Business</a></li>
                <li><a href="#">Appartment</a></li>
                <li><a href="#">Flat</a></li>
                <li><a href="#">Commercial</a></li>
                <li><a href="#">Villa</a></li>
            </ul>
        
        </div>
        
    </div>
</div>

<!-- Color Palate / Color Switcher -->
<div class="color-palate">
    <div class="color-trigger">
        <i class="fas fa-cog"></i>
    </div>
    <div class="color-palate-head">
        <h6>Choose Your Color</h6>
    </div>
    <div class="various-color clearfix">
        <div class="colors-list">
            <span class="palate default-color active" data-theme-file="css/color-themes/default-theme.css"></span>
            <span class="palate yellow-color" data-theme-file="css/color-themes/yellow-theme.css"></span>
            <span class="palate olive-color" data-theme-file="css/color-themes/olive-theme.css"></span>
            <span class="palate orange-color" data-theme-file="css/color-themes/orange-theme.css"></span>
            <span class="palate purple-color" data-theme-file="css/color-themes/purple-theme.css"></span>
            <span class="palate teal-color" data-theme-file="css/color-themes/teal-theme.css"></span>
            <span class="palate brown-color" data-theme-file="css/color-themes/brown-theme.css"></span>
            <span class="palate redd-color" data-theme-file="css/color-themes/redd-color.css"></span>
        </div>
    </div>
	
	<ul class="rtl-version option-box"> <li class="rtl">RTL Version</li> <li>LTR Version</li> </ul>

    <a href="#" class="purchase-btn">Purchase now $17</a>
    
    <div class="palate-foo">
        <span>You will find much more options for colors and styling in admin panel. This color picker is used only for demonstation purposes.</span>
    </div>

</div>

<!--Scroll to top-->
<script src="js/jquery.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/jquery-ui.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.fancybox.js"></script>
<script src="js/jquery.countdown.js"></script>
<script src="js/owl.js"></script>
<script src="js/wow.js"></script>
<script src="js/dropzone.js"></script>
<script src="js/appear.js"></script>
<script src="js/script.js"></script>
<script src="js/color-settings.js"></script>

</body>

<!-- Mirrored from ary-themes.com/html/noor_tech/dream-property/submit-property.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 04 Mar 2021 10:53:32 GMT -->
</html>