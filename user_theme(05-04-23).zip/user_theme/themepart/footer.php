<footer class="footer-style-three">
		<div class="auto-container">
			<!--Widget Section-->
            <div class="widget-section">
				<div class="logo">
					<a href="index.html"><img src="images/footer-logo.png" alt="" /></a>
				</div>
				<div class="copyright">&copy; Copyright 2019 Dream Property - Real Estate . All Rights Reserved </div>
				<ul class="social-icon-one">
					<li><a href="#"><span class="fab fa-facebook-f"></span></a></li>
					<li><a href="#"><span class="fab fa-google"></span></a></li>
					<li><a href="#"><span class="fab fa-twitter"></span></a></li>
					<li><a href="#"><span class="fab fa-skype"></span></a></li>
					<li><a href="#"><span class="fab fa-linkedin-in"></span></a></li>
				</ul>
			</div>
		</div>
	</footer>